<?php

/* CoreBundle:Default:index.html.twig */
class __TwigTemplate_38c7ccda4b0db9a2dcf61c3bf8d0af9da8639f114f6b8515938b4640ef874f94 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello World!
";
    }

    public function getTemplateName()
    {
        return "CoreBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "CoreBundle:Default:index.html.twig", "C:\\wamp64\\www\\marsupilami\\src\\CoreBundle/Resources/views/Default/index.html.twig");
    }
}
